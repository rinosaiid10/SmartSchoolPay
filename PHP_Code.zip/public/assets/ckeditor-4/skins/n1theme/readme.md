"n1ed" skin is theme for CKEditor 4 included into N1ED editor.
